# KwanzaMarket 🇦🇴
Marketplace digital pensado para Angola, com preços em kwanzas (Kz).

## Iniciar
1. Instala Node.js 20 ou superior.
2. Descomprime o projecto.
3. Na pasta do projecto, executa `npm install`.
4. Executa `npm run dev` e abre o endereço indicado pelo Vite.

## Incluído
- Interface adaptável a telemóveis e computadores.
- Pesquisa e filtros de produtos.
- Cartão de produto, favoritos e carrinho demonstrativo.
- Secções para vendedores, afiliados e cursos.
- Modelo inicial de tabelas Supabase.

## Importante
Esta é uma base inicial. Login, base de dados ligada, encomendas persistentes, comissões, pagamentos reais e levantamentos ainda não estão activos. Antes de lançar, implementa autenticação, políticas de acesso (RLS), validação no servidor, testes e aprovação dos fornecedores de pagamento. Nunca publiques chaves secretas no frontend.
