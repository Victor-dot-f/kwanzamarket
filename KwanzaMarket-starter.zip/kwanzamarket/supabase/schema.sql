-- Esquema inicial de referência. Rever antes de usar em produção.
create extension if not exists pgcrypto;

create type public.market_role as enum ('customer','seller','affiliate','trainer','admin');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  role public.market_role not null default 'customer',
  created_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id),
  name text not null,
  description text not null default '',
  category text not null default 'Geral',
  price_aoa bigint not null check (price_aoa >= 0),
  stock integer not null default 0 check (stock >= 0),
  image_url text,
  is_published boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.profiles(id),
  status text not null default 'pending' check (status in ('pending','paid','processing','shipped','completed','cancelled','refunded')),
  total_aoa bigint not null check (total_aoa >= 0),
  payment_provider text,
  provider_reference text unique,
  created_at timestamptz not null default now()
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity integer not null check (quantity > 0),
  unit_price_aoa bigint not null check (unit_price_aoa >= 0)
);

create table public.affiliate_links (
  id uuid primary key default gen_random_uuid(),
  affiliate_id uuid not null references public.profiles(id),
  product_id uuid not null references public.products(id),
  code text not null unique,
  commission_percent numeric(5,2) not null check (commission_percent between 0 and 100),
  created_at timestamptz not null default now()
);

-- Antes de activar RLS, definir políticas específicas para cada tabela.
-- Pagamentos, comissões e mudanças de estado devem ser validados no servidor/webhook.
