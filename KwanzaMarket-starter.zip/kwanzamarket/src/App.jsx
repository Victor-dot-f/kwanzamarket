import { useMemo, useState } from 'react';
import { Search, ShoppingBag, Store, GraduationCap, BadgePercent, ArrowRight, Heart, MapPin, ShieldCheck, Truck, Headphones } from 'lucide-react';

const products = [
 {id:1,name:'Auscultadores Bluetooth',category:'Tecnologia',price:18500,old:23000,tag:'Mais vendido',emoji:'🎧',tone:'lavender',seller:'Tech Luanda'},
 {id:2,name:'Mala elegante feminina',category:'Moda',price:12500,tag:'Novo',emoji:'👜',tone:'peach',seller:'Kriativa Store'},
 {id:3,name:'Ténis urbanos',category:'Moda',price:22000,old:28000,tag:'Promoção',emoji:'👟',tone:'mint',seller:'Passo Certo'},
 {id:4,name:'Kit de cuidados pessoais',category:'Beleza',price:9500,tag:'Popular',emoji:'🧴',tone:'cream',seller:'Bem-Estar AO'},
 {id:5,name:'Curso de Design Gráfico',category:'Cursos',price:15000,tag:'Aprende online',emoji:'🎨',tone:'blue',seller:'Academia Criativa'},
 {id:6,name:'Candeeiro de secretária',category:'Casa',price:17500,old:20000,tag:'Boa escolha',emoji:'💡',tone:'yellow',seller:'Casa Moderna'}
];
const money = n => new Intl.NumberFormat('pt-AO',{maximumFractionDigits:0}).format(n)+' Kz';
const categories=['Todos','Tecnologia','Moda','Beleza','Casa','Cursos'];

export default function App(){
 const [query,setQuery]=useState(''),[category,setCategory]=useState('Todos'),[cart,setCart]=useState([]),[liked,setLiked]=useState([]);
 const visible=useMemo(()=>products.filter(p=>(category==='Todos'||p.category===category)&&`${p.name} ${p.category} ${p.seller}`.toLowerCase().includes(query.toLowerCase())),[query,category]);
 return <div>
  <div className="topline"><span><MapPin size={13}/> Entregas em Angola</span><span>Compra local. Cresce local.</span><span>O mercado é nosso 🇦🇴</span></div>
  <header className="wrap header"><a className="brand" href="#"><span className="brandicon"><ShoppingBag/></span><span>Kwanza<span className="green">Market</span><small>O mercado é nosso</small></span></a>
   <label className="search"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="O que estás à procura?"/></label>
   <button className="cart" onClick={()=>alert(cart.length?`Tens ${cart.length} artigo(s). O checkout ainda não está activo.`:'O teu carrinho está vazio.')}><ShoppingBag size={20}/> Carrinho <b>{cart.length}</b></button>
  </header>
  <nav className="wrap nav">{categories.map(c=><button key={c} className={category===c?'selected':''} onClick={()=>setCategory(c)}>{c}</button>)}</nav>
  <main>
   <section className="wrap hero"><div className="herotext"><span className="eyebrow">A NOVA FORMA DE COMPRAR EM ANGOLA</span><h1>O que precisas.<br/><em>Está aqui.</em></h1><p>Descobre produtos, aprende novas competências e apoia negócios angolanos — tudo num só lugar.</p><button className="primary" onClick={()=>document.getElementById('produtos').scrollIntoView({behavior:'smooth'})}>Explorar mercado <ArrowRight size={18}/></button><div className="proof">🇦🇴 <span><b>Feito para Angola</b><small>Negócios locais, novas oportunidades</small></span></div></div><div className="heroart"><div className="orbit"></div><div className="bag">🛍️</div><div className="float f1">✨ <span><b>Feito cá</b><small>Para todos nós</small></span></div><div className="float f2">✓ <span><b>Compra · Aprende · Vende</b><small>Oportunidades para crescer</small></span></div></div></section>
   <section className="wrap benefits"><div><ShieldCheck/><span><b>Compra com confiança</b><small>Mais transparência em cada compra</small></span></div><div><Truck/><span><b>Entrega combinada</b><small>Detalhes alinhados com o vendedor</small></span></div><div><Headphones/><span><b>Apoio próximo</b><small>Pensado para Angola</small></span></div></section>
   <section className="wrap section" id="produtos"><div className="sectionhead"><div><span className="eyebrow">ESCOLHAS PARA TI</span><h2>Descobre o mercado<span className="green">.</span></h2><p>Produtos e oportunidades para o teu dia a dia.</p></div><small>{visible.length} artigos</small></div><div className="grid">{visible.map(p=><article className="product" key={p.id}><div className={`productart ${p.tone}`}><span className="tag">{p.tag}</span><button className={liked.includes(p.id)?'heart liked':'heart'} onClick={()=>setLiked(a=>a.includes(p.id)?a.filter(i=>i!==p.id):[...a,p.id])} aria-label="Guardar favorito"><Heart size={18}/></button><span className="emoji">{p.emoji}</span></div><div className="productbody"><small className="green">{p.category}</small><h3>{p.name}</h3><small className="seller"><Store size={13}/>{p.seller}</small><div className="price"><b>{money(p.price)}</b>{p.old&&<del>{money(p.old)}</del>}</div><button className="add" onClick={()=>setCart(a=>[...a,p])}>Adicionar ao carrinho <ArrowRight size={15}/></button></div></article>)}</div>{!visible.length&&<p className="empty">Não encontrámos artigos. Experimenta outra pesquisa.</p>}</section>
   <section className="wrap sellerbanner"><Store size={34}/><div><small>O TEU NEGÓCIO MERECE CRESCER</small><h2>Transforma o teu talento numa oportunidade.</h2><p>Prepara a tua loja e apresenta os teus produtos a novos clientes.</p></div><button onClick={()=>alert('O registo de vendedores será activado na próxima fase.')}>Quero vender <ArrowRight size={18}/></button></section>
   <section className="wrap section ways"><div className="sectionhead"><div><span className="eyebrow">MAIS DO QUE COMPRAS</span><h2>Há espaço para crescer<span className="green">.</span></h2><p>Uma plataforma, diferentes formas de participar.</p></div></div><div className="waygrid"><article><Store/><h3>Vende produtos</h3><p>Apresenta artigos e gere a tua loja num só lugar.</p></article><article><BadgePercent/><h3>Promove como afiliado</h3><p>Acompanha comissões quando as vendas forem confirmadas.</p></article><article><GraduationCap/><h3>Ensina o que sabes</h3><p>Prepara cursos e partilha as tuas competências.</p></article></div></section>
  </main>
  <footer><div className="wrap foot"><b>Kwanza<span className="green">Market</span> 🇦🇴</b><span>Protótipo inicial · Pagamentos reais ainda não activos</span></div><div className="footbottom">© {new Date().getFullYear()} KwanzaMarket · Comprar · Vender · Aprender · Preços em Kz</div></footer>
 </div>
}
